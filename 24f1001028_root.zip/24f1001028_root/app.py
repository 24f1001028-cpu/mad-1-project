from flask import Flask
import os
from models import init_db
from routes import register_routes



placement_portal_app = Flask(__name__)


placement_portal_app.secret_key = "placementportal123"



BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Instance folder for database
INSTANCE_FOLDER = os.path.join(BASE_DIR, "instance")
os.makedirs(INSTANCE_FOLDER, exist_ok=True)

# Resume upload folder
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "resumes")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

placement_portal_app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER



init_db()




register_routes(placement_portal_app)




if __name__ == "__main__":
    placement_portal_app.run(debug=True)

